<?php  if ( ! defined("BASEPATH")) exit("No direct script access allowed");
	function generate_sidemenu()
	{
		return '<li>
		<a href="'.site_url('user').'"><i class="fa fa-list fa-fw"></i> User</a>
	</li>';
	}
