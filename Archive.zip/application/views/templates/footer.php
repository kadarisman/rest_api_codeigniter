<footer style="width:100%; padding:10px; background:#FFFFFF; text-align:center;">
		Copyright &copy MMZ Praktikum Framework <?php echo date("Y"); ?>
	</footer>
</div>
</div>	
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
		<script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script src="<?php echo base_url('assets/vendor/metisMenu/metisMenu.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/sb-admin-2.js') ?>"></script>
        
    </body>
</html>